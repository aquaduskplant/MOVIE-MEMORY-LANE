import React from 'react';
import { Link, usePage } from '@inertiajs/react';

export default function AppLayout({ children }) {
  const { auth, flash } = usePage().props;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 flex flex-col">
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-4 py-3">
          <Link href={route('movies.index')} className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 rounded-full bg-pink-500/80" />
            <div className="leading-tight">
              <p className="font-semibold tracking-tight">Movie Memory Lane</p>
              <p className="text-xs text-slate-400">Films that leave a mark</p>
            </div>
          </Link>

          <nav className="flex items-center gap-4 text-sm">
            {auth?.user && (
              <>
                <Link
                  href={route('memories.index')}
                  className="text-slate-300 hover:text-pink-300 transition"
                >
                  My Memories
                </Link>
                <span className="text-xs text-slate-500 hidden sm:inline">
                  {auth.user.name}
                </span>
                <Link
                  href={route('logout')}
                  method="post"
                  as="button"
                  className="px-3 py-1 rounded-full border border-slate-700 text-xs hover:bg-slate-800"
                >
                  Logout
                </Link>
              </>
            )}

            {!auth?.user && (
              <>
                <Link
                  href={route('login')}
                  className="text-slate-300 hover:text-pink-300 transition"
                >
                  Log in
                </Link>
                <Link
                  href={route('register')}
                  className="px-3 py-1 rounded-full bg-pink-500 hover:bg-pink-400 text-xs font-semibold text-slate-950 transition"
                >
                  Sign up
                </Link>
              </>
            )}
          </nav>
        </div>
      </header>

      {flash?.success && (
        <div className="bg-emerald-500/10 text-emerald-200 text-sm py-2">
          <div className="max-w-6xl mx-auto px-4">{flash.success}</div>
        </div>
      )}

      <main className="flex-1">
        {children}
      </main>

      <footer className="border-t border-slate-800 text-xs text-slate-500 py-4">
        <div className="max-w-6xl mx-auto px-4 flex justify-between items-center">
          <p>&copy; {new Date().getFullYear()} Movie Memory Lane</p>
          <p className="hidden sm:inline">Built with Laravel, Inertia &amp; React</p>
        </div>
      </footer>
    </div>
  );
}
