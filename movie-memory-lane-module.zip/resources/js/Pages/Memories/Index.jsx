import React from 'react';
import { Link, useForm, usePage } from '@inertiajs/react';
import AppLayout from '../../Layouts/AppLayout';

export default function Index() {
  const { memories } = usePage().props;

  return (
    <AppLayout>
      <div className="max-w-5xl mx-auto px-4 py-10 space-y-6">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-pink-300/70">
              Your personal cinema log
            </p>
            <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
              My Movie Memories
            </h1>
            <p className="text-slate-300 text-sm max-w-xl mt-1">
              Every film here is more than just a title — it&apos;s a snapshot of when, where,
              and how it met you in real life.
            </p>
          </div>
          <Link
            href={route('movies.index')}
            className="text-xs text-slate-400 hover:text-pink-300"
          >
            ← Back to Movie Memory Lane
          </Link>
        </div>

        {memories.length === 0 && (
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 text-sm text-slate-300">
            You haven&apos;t saved any memories yet. Head back to the main page, pick a movie,
            and add your first one.
          </div>
        )}

        <div className="space-y-4">
          {memories.map((memory) => (
            <MemoryCard key={memory.id} memory={memory} />
          ))}
        </div>
      </div>
    </AppLayout>
  );
}

function MemoryCard({ memory }) {
  const { delete: destroy, processing } = useForm();

  const handleDelete = () => {
    if (!window.confirm('Remove this memory?')) return;
    destroy(route('memories.destroy', memory.id));
  };

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5 flex flex-col md:flex-row md:items-start gap-4">
      <div className="flex-1 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <div>
            <p className="text-sm font-semibold text-slate-50">
              {memory.movie_title}
            </p>
            <p className="text-[11px] text-slate-400">Movie ID: {memory.movie_id}</p>
          </div>
          {memory.rating && (
            <p className="text-xs px-2 py-1 rounded-full bg-pink-500/20 text-pink-200 border border-pink-500/40">
              {memory.rating}/5
            </p>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs text-slate-300">
          {memory.watched_on && (
            <p>
              <span className="text-slate-400">Watched on: </span>
              {memory.watched_on}
            </p>
          )}
          {memory.feeling && (
            <p>
              <span className="text-slate-400">Felt: </span>
              {memory.feeling}
            </p>
          )}
        </div>

        {memory.notes && (
          <p className="text-sm text-slate-200 mt-1 whitespace-pre-line">
            {memory.notes}
          </p>
        )}
      </div>

      <div className="flex md:flex-col items-center gap-2 text-xs">
        <Link
          href={route('movies.show', memory.movie_id)}
          className="px-3 py-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-100"
        >
          View movie
        </Link>
        <button
          type="button"
          onClick={handleDelete}
          disabled={processing}
          className="px-3 py-1.5 rounded-full border border-red-500/40 text-red-300 hover:bg-red-500/10 disabled:opacity-60"
        >
          Remove
        </button>
      </div>
    </div>
  );
}
