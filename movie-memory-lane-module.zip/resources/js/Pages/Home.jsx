import React from 'react';
import { Link, usePage } from '@inertiajs/react';
import AppLayout from '../Layouts/AppLayout';

export default function Home() {
  const { sections = [], error } = usePage().props;

  return (
    <AppLayout>
      <div className="max-w-6xl mx-auto px-4 py-10 space-y-16">
        <section className="grid md:grid-cols-2 gap-10 items-center">
          <div className="space-y-4">
            <p className="text-xs uppercase tracking-[0.2em] text-pink-300/70">
              A cinematic way to remember
            </p>
            <h1 className="text-4xl md:text-5xl font-semibold tracking-tight">
              Turn Studio Ghibli films into{" "}
              <span className="text-pink-400">personal memories</span>.
            </h1>
            <p className="text-slate-300 leading-relaxed">
              Movie Memory Lane is a guided scroll through iconic Studio Ghibli films —
              not just as titles on a screen, but as chapters of your own story. Browse
              cozy classics, epic adventures, and emotional journeys, then save how each
              one made you feel.
            </p>
            <div className="flex flex-wrap gap-3 pt-2">
              <Link
                href="#comforting"
                className="px-4 py-2 rounded-full bg-pink-500 hover:bg-pink-400 text-sm font-medium text-slate-950 transition"
              >
                Start the journey
              </Link>
              <Link
                href="#epic"
                className="px-4 py-2 rounded-full border border-slate-700 hover:bg-slate-900 text-sm text-slate-200 transition"
              >
                Jump to epic adventures
              </Link>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/5] rounded-3xl bg-gradient-to-br from-pink-500/40 via-slate-900 to-indigo-500/40 overflow-hidden border border-pink-500/20 shadow-[0_0_80px_rgba(236,72,153,0.35)]">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_rgba(248,250,252,0.1),_transparent)]" />
              <div className="absolute top-8 left-8 right-8 space-y-4 text-sm">
                <p className="text-xs text-pink-100/80">Tonight&apos;s feature</p>
                <p className="font-semibold text-slate-50 text-lg">Your favorite Ghibli memory</p>
                <p className="text-slate-200/80">
                  Log in, pick a film, and capture when you watched it, who you were with,
                  and why it stuck with you.
                </p>
              </div>
              <div className="absolute bottom-8 left-8 right-8 grid grid-cols-3 gap-2 text-[10px] text-slate-100/80">
                <div className="bg-slate-900/50 rounded-xl p-2 border border-slate-700/60">
                  <p className="font-semibold">Cozy nights</p>
                  <p className="text-slate-400">Comforting picks for soft, slow evenings.</p>
                </div>
                <div className="bg-slate-900/50 rounded-xl p-2 border border-slate-700/60">
                  <p className="font-semibold">Big journeys</p>
                  <p className="text-slate-400">Worlds worth getting lost in.</p>
                </div>
                <div className="bg-slate-900/50 rounded-xl p-2 border border-slate-700/60">
                  <p className="font-semibold">Heart moments</p>
                  <p className="text-slate-400">The ones that made you feel everything.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {error && (
          <div className="rounded-xl border border-red-500/40 bg-red-500/10 text-red-100 px-4 py-3 text-sm">
            {error}
          </div>
        )}

        {sections.map((section) => (
          <section key={section.slug} id={section.slug} className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4">
              <div>
                <h2 className="text-2xl font-semibold tracking-tight">{section.title}</h2>
                <p className="text-slate-300 text-sm mt-1 max-w-2xl">
                  {section.description}
                </p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {section.movies?.map((movie) => (
                <Link
                  key={movie.id}
                  href={route('movies.show', movie.id)}
                  className="group rounded-2xl border border-slate-800 bg-slate-900/40 overflow-hidden hover:border-pink-400/60 hover:bg-slate-900 transition"
                >
                  <div className="aspect-[3/4] overflow-hidden">
                    <div className="w-full h-full bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center text-slate-500 text-xs p-4">
                      {movie.title}
                    </div>
                  </div>
                  <div className="p-4 space-y-2">
                    <p className="text-xs uppercase tracking-[0.2em] text-pink-300/70">
                      {movie.release_date} • Score {movie.rt_score}
                    </p>
                    <p className="font-semibold text-sm group-hover:text-pink-200">
                      {movie.title}
                    </p>
                    <p className="text-xs text-slate-400 line-clamp-3">
                      {movie.description}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </AppLayout>
  );
}
